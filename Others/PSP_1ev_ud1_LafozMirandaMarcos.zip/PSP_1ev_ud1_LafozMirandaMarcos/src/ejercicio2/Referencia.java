package ejercicio2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class Referencia {

	public static void main(String[] args) throws IOException {
		// Declaración de variables
		BufferedReader entrada = null;
		PrintStream salida = null;

		try {
			// Lo recibe del padre
			entrada = new BufferedReader(new InputStreamReader(System.in));
			// Se manda al padre
			salida = new PrintStream(System.out);
			String linea = entrada.readLine();

			while (linea != null) {
				try {
					salida.println(mostrarRef(linea));
					salida.flush();

				} catch (NumberFormatException e) {
					// Enviar mensaje de dato no válido al padre
					salida.println("dato_invalido");
					salida.flush();
				}
				// Indicar al padre que ha terminado este proceso hijo
				salida.println("finproceso");
				salida.flush();

				// Volvemos a preguntar al Padre
				linea = entrada.readLine();
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			entrada.close();
			salida.close();
		}
	}

	public static String mostrarRef(String linea) {

		String resultados = "Resultados: ";

		if (linea.equals("0000")) {
			return resultados;
		} else {
			return null;
		}
	}

}
