package ejercicio2;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class Ejercicio02 {

	public static void main(String[] args) {
		// Declaración de variables
		BufferedReader entradaHijo = null;
		PrintStream salidaHijo = null;
		String numero, linea;

		try {
			// Configuración del directorio donde se encuentra el proceso hijo
			File directorioBin = new File("bin");
			Runtime runtime = Runtime.getRuntime();

			Process hijo = null;

			// Preparación para leer desde la entrada estándar
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Escribe un codigo");
			linea = teclado.readLine();

			while (linea != null && !linea.equals("fin")) {
				// Iniciar el proceso hijo
				hijo = runtime.exec("java ejercicio2.Referencia", null, directorioBin);

				// Preparación para leer desde la salida del proceso hijo
				entradaHijo = new BufferedReader(new InputStreamReader(hijo.getInputStream()));
				// Preparación para escribir en la entrada del proceso hijo
				salidaHijo = new PrintStream(hijo.getOutputStream());

				// Enviar la línea al proceso hijo

				if (esValido(linea)) {
					salidaHijo.println(linea);
					salidaHijo.flush(); // Asegura que los datos se han enviado
				} else {
					System.out.println("El codigo introducido no es valido");
				}

				salidaHijo.println(linea);

				salidaHijo.flush(); // Asegura que los datos se han enviado
				numero = entradaHijo.readLine();

				while (numero != null && !numero.equals("finproceso")) {
					// Mostrar la respuesta del proceso hijo
					if (numero.equals("dato_invalido")) {
						System.out.println("Dato no válido");
					} else {
						System.out.println(numero);
					}
					numero = entradaHijo.readLine();
				}

				System.out.println("Escribe un codigo ");
				// Vuelve a preguntar al usuario
				linea = teclado.readLine();
			}

			hijo.waitFor(); // Espera a que el proceso hijo termine

		} catch (IOException ex) {
			System.err.println(ex.getMessage());
			ex.printStackTrace();
		} catch (InterruptedException e) {
			System.err.println("Error al esperar al proceso hijo: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (entradaHijo != null) {
					entradaHijo.close();
				}
				if (salidaHijo != null) {
					salidaHijo.close();
				}
			} catch (Exception e) {
				System.err.println(e.getMessage());
			}
		}
	}

	// Metodo para verificar si el codigo es valido
	public static boolean esValido(String codigo) {

		if (codigo.charAt(0) == '7' && (codigo.charAt(3) == 'Y' || codigo.charAt(3) == 'Z') || codigo.equals("0000")) {
			return true;
		} else {
			return false;
		}

	}
}
