package ejercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class SonPares {
	public static void main(String[] args) throws IOException {
		// Preparar flujos de entrada y salida
		BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
		PrintStream salida = new PrintStream(System.out);

		// Leer la primera línea de entrada
		String linea = entrada.readLine();

		// Procesar líneas hasta que no haya más entradas
		while (linea != null) {
			salida.println(verificarPares(linea));
			salida.flush();
			linea = entrada.readLine(); // Leer la siguiente línea
		}

		// Finalizar el proceso hijo
		System.exit(0);
	}

	public static String verificarPares(String linea) {

		int n1 = Integer.parseInt(linea);

		if (n1 % 2 == 0) {
			return "El numero " + n1 + " es par";
		} else {
			return "El numero " + n1 + " es impar";
		}
	}

}
