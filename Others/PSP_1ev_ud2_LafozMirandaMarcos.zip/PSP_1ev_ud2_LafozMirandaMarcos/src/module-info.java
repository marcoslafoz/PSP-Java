module Template {
	requires teclado;
}