package ejercicio2;

public class Coche extends Thread {
	int id;
	Turno turno;
	int tiempoEspera;

	public Coche(int id, Turno turno, int tiempoEspera) {
		super();
		this.id = id;
		this.turno = turno;
		this.tiempoEspera = tiempoEspera;
	}

	@Override
	public void run() {
		try {
			System.out.println(id + " se pone en cola");

			int nPuesto = turno.permitirEntrada(id);

			System.out.println("Atendiendo a " + id);
			System.out.println(id + " espera " + this.tiempoEspera);

			Thread.sleep(this.tiempoEspera);
			turno.permitirSalida(nPuesto);

			System.out.println("Liberando puesto");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}