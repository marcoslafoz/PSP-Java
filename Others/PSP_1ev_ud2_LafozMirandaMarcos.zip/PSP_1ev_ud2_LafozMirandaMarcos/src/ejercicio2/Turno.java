package ejercicio2;

public class Turno extends Thread {
	int puesto[];
	int libres;

	public Turno(int totalPuestos) {
		super();
		this.puesto = new int[totalPuestos];
		this.libres = totalPuestos;
	}

	synchronized public int permitirEntrada(int idcoche) throws InterruptedException {

		int nPuesto = 0;
		while (libres == 0) {
			wait();
		}

		while (puesto[nPuesto] != 0) {
			nPuesto++;
		}
		puesto[nPuesto] = idcoche;
		libres--;
		return nPuesto;

	}

	synchronized public void permitirSalida(int posicion) {
		puesto[posicion] = 0;
		libres++;
		notifyAll();
	}

}