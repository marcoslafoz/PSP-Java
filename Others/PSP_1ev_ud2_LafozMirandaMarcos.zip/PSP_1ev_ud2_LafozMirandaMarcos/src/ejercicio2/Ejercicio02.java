package ejercicio2;

import java.time.LocalDateTime;
import java.util.Random;

public class Ejercicio02 {

	public static void main(String[] args) {

		final int PUESTOS = 2;
		final int NUM_COCHES = 5;

		Turno turno = new Turno(PUESTOS);
		Coche coches[] = new Coche[NUM_COCHES];

		System.out.println("-------> Estación abierta " + LocalDateTime.now().toLocalTime());

		for (int i = 0; i < coches.length; i++) {
			coches[i] = new Coche(i + 1, turno, new Random().nextInt(1000));
			coches[i].start();
		}

		try {
			for (int i = 0; i < coches.length; i++) {
				coches[i].join();
			}
			System.out.println("-------> Estación cerrada " + LocalDateTime.now().toLocalTime());
		} catch (InterruptedException e) {
			System.out.println("Programa interrumpido");
		}

	}

}