package ejercicio1;

import java.util.Random;
import java.util.concurrent.Semaphore;

class Persona extends Thread {
	private static int contador = 1;
	private int id;
	private Semaphore semaforo;
	private int tiempoEspera;

	public Persona(Semaphore semaforo) {
		this.id = contador++;
		this.semaforo = semaforo;
		this.tiempoEspera = new Random().nextInt(4900 + 100);
	}

	@Override
	public void run() {
		try {
			semaforo.acquire();
			System.out.println("Persona " + id + " entra durante " + tiempoEspera + " milisegundos");
			Thread.sleep(tiempoEspera);
			System.out.println("Persona " + id + " va a salir");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaforo.release();
		}
	}
}

public class Ejercicio01 {
	public static void main(String[] args) throws InterruptedException {

		final int N_PERSONAS = 10;
		final int CAPACIDAD_SALA = 5;

		Semaphore semaforo = new Semaphore(CAPACIDAD_SALA);
		Persona personas[] = new Persona[N_PERSONAS];

		for (int i = 0; i < personas.length; i++) {
			Thread.sleep(10);
			System.out.println("Persona " + i + " quiere entrar");
			personas[i] = new Persona(semaforo);
			personas[i].start();
		}
		
		System.out.println("Fin de la simulación");

	}
}
