package ejercicio1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class Hilo extends Thread {
	private Socket clienteSocket;
	private List<Equipo> listaEquipos;

	public Hilo(Socket clienteSocket, List<Equipo> listaEquipos) {
		this.clienteSocket = clienteSocket;
		this.listaEquipos = listaEquipos;
	}

	@Override
	public void run() {
		PrintWriter fsalida;
		BufferedReader fentrada;
		try {

			fsalida = new PrintWriter(clienteSocket.getOutputStream(), true);
			fentrada = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));

			fsalida.println("Indica el nombre de tu equipo (" + listaEquipos.toString() + ")");

			String respuesta = fentrada.readLine();

			String ultimaLetraEquipo;

			String textoResumen = "";

			// Asignar voto

			for (Equipo e : listaEquipos) {

				ultimaLetraEquipo = e.getNombre().toLowerCase().charAt(e.getNombre().length() - 1) + "";
				if (ultimaLetraEquipo.equals(respuesta)) {
					e.aumentarVoto();
				}

			}

			for (Equipo e : listaEquipos) {
				textoResumen += e.mostrarResumen() + " ";
			}

			fsalida.println(" -- Recuento -- ");
			fsalida.println(textoResumen);

			// Cerrar conexiones
			fsalida.close();
			fentrada.close();
			clienteSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}