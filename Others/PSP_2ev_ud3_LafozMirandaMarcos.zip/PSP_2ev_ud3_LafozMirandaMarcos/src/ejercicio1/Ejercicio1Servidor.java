package ejercicio1;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

import entrada.Teclado;

public class Ejercicio1Servidor {
	public static void main(String[] args) {
		ServerSocket serverSocket = null;
		Socket clienteSocket = null;
		List<Equipo> listaEquipos = new ArrayList<>();
		int numeroEquipos = 0;

		try {
			serverSocket = new ServerSocket(ServerConfig.puertoServidor);
			System.out.println("Servidor iniciado. Esperando clientes...");

			numeroEquipos = Teclado.leerEntero("¿Cantidad de equipos?");

			for (int i = 1; i <= numeroEquipos; i++) {
				listaEquipos.add(new Equipo(Teclado.leerCadena("¿Nombre equipo " + i + "?")));
			}

			System.out.println("Esperando votaciones...");

			while (true) {
				clienteSocket = serverSocket.accept();
				System.out.println("Nuevo cliente conectado");

				// Crear un nuevo hilo para manejar el cliente
				Hilo clientThread = new Hilo(clienteSocket, listaEquipos);
				clientThread.start();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
