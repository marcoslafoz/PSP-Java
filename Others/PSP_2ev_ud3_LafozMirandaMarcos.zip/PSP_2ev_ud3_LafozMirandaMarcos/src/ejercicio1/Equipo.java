package ejercicio1;

public class Equipo {

	private String nombre;

	private int contadorVotos = 0;

	public Equipo(String nombre) {
		this.nombre = nombre;
	}

	public void aumentarVoto() {
		this.contadorVotos++;
	}

	@Override
	public String toString() {
		return nombre;
	}

	//////

	public String getNombre() {
		return nombre;
	}

	public String mostrarResumen() {
		return nombre + ": " + contadorVotos + " votos";
	}

}
