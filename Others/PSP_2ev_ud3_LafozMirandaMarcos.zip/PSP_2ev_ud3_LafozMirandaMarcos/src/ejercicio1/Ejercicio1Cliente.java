package ejercicio1;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import entrada.Teclado;

public class Ejercicio1Cliente {
	public static void main(String[] args) {

		PrintWriter fsalida;
		BufferedReader fentrada;
		Socket socket;

		try {
			socket = new Socket(ServerConfig.ipServidor, ServerConfig.puertoServidor);

			fsalida = new PrintWriter(socket.getOutputStream(), true);
			fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			String pregunta = (String) fentrada.readLine();
			System.out.println(pregunta);

			String respuesta = Teclado.leerCadena("-> ");

			String letraRespuesta = respuesta.toLowerCase().charAt(respuesta.length() - 1) + "";

			fsalida.println(letraRespuesta);

			String indicadorRecuento = (String) fentrada.readLine();
			System.out.println(indicadorRecuento);

			String resumen = (String) fentrada.readLine();
			System.out.println(resumen);

			// Cerrar conexiones
			fsalida.close();
			fentrada.close();
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
