package ejercicio1;

public class ServerConfig {
	public static final String ipServidor = "localhost";
	public static final int puertoServidor = 12345;
}
