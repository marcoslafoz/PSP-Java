package ejercicio2;

import java.net.*;

/**
 * Iniciamos primero este ejercicio y luego el Ejercicio2A.java
 */

public class Ejercicio2B {
	public static void main(String[] args) {
		DatagramSocket socket;
		try {

			// Recibimos mensaje
			byte[] receiveData = new byte[1024];
			socket = new DatagramSocket(12345);
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			socket.receive(receivePacket);
			String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());

			// Modificacion
			//receivedMessage ;
			
			String resultado = "";
			
			for(int i = 1 ; i <= receivedMessage.length() ; i++) {
				resultado += receivedMessage.charAt(receivedMessage.length()-i);
			}

			// Enviamos mensaje
			InetAddress address = receivePacket.getAddress();
			int port = receivePacket.getPort();
			byte[] sendData = resultado.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, address, port);
			socket.send(sendPacket);

			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}