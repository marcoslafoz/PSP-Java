package ejercicio2;

import java.net.*;
import java.util.regex.Pattern;

import entrada.Teclado;

/**
 * Iniciamos primero el Ejercicio2B.java y luego este
 */

public class Ejercicio2A {
	public static void main(String[] args) {

		InetAddress address;
		DatagramSocket socket;
		try {
			socket = new DatagramSocket();
			address = InetAddress.getLocalHost();

			boolean valido = false;

			String mensaje = "";

			while (!valido) {
				mensaje = Teclado.leerCadena("Indica clave: ");

				if (mensaje.length() == 8) {
					//if (Pattern.matches("[0-9]",mensaje)) {
						valido = true;
//					} else {
//						System.out.println("Clave no válida");
//					}

				} else {
					System.out.println("Clave no válida");
				}
			}

			// Validamos

			// Enviamos mensaje
			byte[] sendData = mensaje.getBytes();
			DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, address, 12345);
			socket.send(sendPacket);

			// Recibimos mensaje
			byte[] receiveData = new byte[1024];
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			socket.receive(receivePacket);
			String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());

			// Imprimimos mensaje
			System.out.println("Respuesta: " + receivedMessage);

			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
