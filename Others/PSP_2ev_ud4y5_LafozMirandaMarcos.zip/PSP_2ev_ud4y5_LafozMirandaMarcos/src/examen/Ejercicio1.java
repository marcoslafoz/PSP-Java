package examen;

import entrada.Teclado;

public class Ejercicio1 {
	public static void main(String[] args) {

		try {
			int opcion = -1;
			String texto;

			while (opcion != 3) {
				System.out.println("1. Cifrar una palabra");
				System.out.println("2. Descifrar una palabra");
				System.out.println("3. Salir");
				opcion = Teclado.leerEntero("Introduce una opci�n: ");

				switch (opcion) {

				//////////////////// CIFRAR //////////////////////
				case 1:

					texto = CifradoPolybios.cifrar(Teclado.leerCadena("Introduce la palabra a cifrar: "));
					System.out.println("RESULTADO CIFRADO: " + texto);
					break;

				//////////////////// DESCIFRAR //////////////////////
				case 2:

					texto = CifradoPolybios.descifrar(Teclado.leerCadena("Introduce la palabra a descifrar: "));
					System.out.println("RESULTADO DESCIFRADO: " + texto);

					break;

				case 3:

					System.out.println("Saliendo del programa.");
					break;

				//////////////////// DEFAULT //////////////////////
				default:
					System.out.println("\nOpcion inv�lida.");
					break;

				}
			}
		} catch (Exception e) {
			System.out.println("Error");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}
}
