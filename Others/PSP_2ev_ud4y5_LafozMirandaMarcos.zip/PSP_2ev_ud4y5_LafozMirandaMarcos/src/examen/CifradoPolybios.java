package examen;

public class CifradoPolybios {

	public static String cifrar(String palabra) {
		final String[] DATOS = { "ABCDE", "FGHIJ", "LMNOP", "QRSTU", "VWXYZ" };
		StringBuilder resultado = new StringBuilder();

		char letraAux1;
		char letraAux2;

		for (int i = 0; i < palabra.length(); i++) {
			for (int x = 0; x < 5; x++) {
				for (int y = 0; y < 5; y++) {

					letraAux1 = palabra.toUpperCase().charAt(i);
					letraAux2 = DATOS[x].charAt(y);

					if (letraAux1 == letraAux2) {
						resultado.append("" + (x + 1) + "" + (y + 1));
					}
				}
			}
		}

		return resultado.toString();
	}
	
	public static String descifrar(String palabra) {
		final String[] DATOS = { "ABCDE", "FGHIJ", "LMNOP", "QRSTU", "VWXYZ" };
		StringBuilder resultado = new StringBuilder();

		int letraAux1;
		int letraAux2;

		for (int i = 1; i <= palabra.length(); i= i+2) {
			
			letraAux1 = Integer.parseInt(palabra.charAt(i-1)+"");
			letraAux2 = Integer.parseInt(palabra.charAt(i)+"");
			resultado.append(DATOS[letraAux1-1]).charAt(letraAux2-1);
		}

		return resultado.toString();
	}

}